# One Prompt a Day — Card News 스킬 작업 로그 (최종본)

> 최종 갱신: 2026-05-31 · Leo(레오) ↔ Jason(@ssuperwasabi)
> 목적: 오늘 전체 작업 + 회사 장비에서 이어 디벨롭하기 위한 인수인계
> 상태: **세션 1 완료** — 스킬 구축 + 첫 실전 덱 제작 + 다운로드/비율 버그 2건 해결·검증 완료

---

## 0. 한눈에 보기

1pd 포스트 → **StudioBlank 스타일 카드뉴스(1080×1080)** 자동 제작 Agent Skill **`card-news`** 완성.
실제 콘텐츠(포트레이트 12장)로 **18장 덱**을 뽑았고, **PNG(개별)/ZIP(전체) 다운로드 + 이미지 비율
모두 정상 검증·Jason 확인 완료**.

---

## 1. 스킬 본체

위치: `C:\Users\sodad\.claude\skills\card-news\`

| 파일 | 역할 |
|------|------|
| `SKILL.md` | 매니페스트 + 1pd→카드 매핑 + 비주얼 규칙 + 기술 주의사항 |
| `card-news.css` | StudioBlank 토큰(1080² 카드용, 자체완결). 표지/이미지/스텝/인사이트/아웃트로 카드 스타일 |
| `template.html` | 동작하는 7장 레퍼런스 덱 + PNG/ZIP 추출 엔진 |
| `html2canvas.min.js` | 카드 → 캔버스 래스터화 (로컬 번들, 오프라인 안전) |
| `jszip.min.js` | 전체 카드 → ZIP 단일 다운로드 |

> 스킬은 폴더 하나로 자체완결. 어느 장비든 `~/.claude/skills/`에 복사하면 동작.

---

## 2. 확정된 사양·원칙

- 비주얼: **StudioBlank** (모노크롬·미니멀·직각·Inter, 그림자/이모지/장식 금지)
- 사이즈: **1:1 정사각 1080×1080**
- 출력: **HTML 카드 + 카드 내 PNG 다운로드(개별) + 전체 ZIP 다운로드**
- 입력: **1pd 포스트** (+ inbox 폴더의 이미지/영상 스틸)
- 푸터: **텍스트 전용 `@ssuperwasabi`** — 원작자(StudioBlank) ■ 마크 사용 금지(IP)
- **이미지 = 1장당 1카드, 스와이프형. 그리드 압축 금지** (공들인 작업물은 각각 크게)
- 카드 수 유연, **캐러셀 한도 20장**(Instagram·Threads) 내. 넘으면 뺄 컷을 물어봄

## 3. 카드 구성 (1pd 포스트 분해)

`표지(ink) → 이미지 쇼케이스(1장당 1카드) → 워크플로우 스텝 → 인사이트 → 아웃트로(ink)`
- 이미지 카드: 박스 비율로 미리 크롭한 `<img>`(1080×960) + 하단 슬림 모노 캡션(120px, `tool · subject · medium`)
- 미디어 없는 텍스트 전용 덱: 5~7장

---

## 4. 입력 워크플로우 (inbox)

위치: `C:\Users\sodad\Downloads\One Prompt a Day Card news\inbox\`

```
inbox/_TEMPLATE/post.md      ← 복사해서 채우는 입력 시트
inbox/<YYYY-MM-DD-슬러그>/    ← 포스트당 폴더
   post.md, cover.png, 01.png …, video-still.png, notes.txt
```
- 텍스트: post.md 또는 대화창 붙여넣기
- 이미지: **파일로** (base64로 카드에 박힘). 넣은 건 다 보여줌(큐레이션 = 무엇을 넣느냐)
- 영상: Leo는 재생 불가 → **대표 스틸 1장 + 텍스트 설명**

---

## 5. 첫 실전 산출물 (검수 통과)

- 입력: `inbox/2026-05-30-post1/` (Magnific 포트레이트 12장) + 1pd 초안
- 포스트: Gemini → GPT Image2 → Magnific / "Close-up portrait series"
- 산출: **`1pd-2026-05-30-portraits.html`** (18장 = 표지+이미지12+스텝3+인사이트+아웃트로, 2.6MB)
- 크롭/비율: 중앙 cover-crop OK, PNG 다운로드 비율 정상 (Jason 확인 완료)
- 재생성기: `_build-deck.ps1` (이미지 cover-crop 1080×960→base64→18장 조립, **ASCII 전용**)

다시 뽑으려면:
```
powershell -File "C:\Users\sodad\Downloads\One Prompt a Day Card news\_build-deck.ps1"
```

---

## 6. ★ 다운로드 버그 — 원인과 해결 (중요)

**증상:** PNG 다운로드 버튼이 전부 무반응 (개별·전체 모두).

**진짜 원인:** *멀티다운로드 차단이 아니라* **인라인 JS 문법 오류**.
생성기 `.ps1` 안의 유니코드(`…`,`→`,`↓`,`·`,`—`)를 **Windows PowerShell 5.1이 no-BOM UTF-8
스크립트를 ANSI 코드페이지로 읽어** 깨뜨렸고, 그게 JS 문자열을 망가뜨려
(`'rendering …'` → `'rendering ??)`) **스크립트 전체 파싱 실패 → dl/dlAll 미정의 → 모든 버튼 사망.**
(진단 페이지는 별도의 정상 JS라 동작했고, 손으로 쓴 harbor 덱도 정상이었음 → 범위가 생성기로 좁혀짐)

**해결:**
1. 생성기 **ASCII 전용** 재작성 — 표시 글자는 HTML 엔티티(`&mdash; &rarr; &darr; &middot;`),
   JS 문자열은 순수 ASCII. `node --check`로 인라인 JS 검증.
2. 전체 다운로드 = **ZIP 단일 파일**(JSZip) — 혹시 모를 크롬 멀티다운로드 차단도 우회.
3. `toDataURL` → **`toBlob` + objectURL** (대용량 PNG data URL을 크롬이 무시하는 문제 예방).
4. 캡처 전 **`img.decode()` 대기** (이미지 카드 블랭크 방지).
5. html2canvas/JSZip **로컬 번들** (CDN 차단/오프라인 안전).

**검증(헤드리스 크롬, puppeteer-core):**
```
TEST 1 단발 PNG  → 1pd-card-02.png 1080×1080 ✓
TEST 2 전체 ZIP  → 1pd-2026-05-30-portraits.zip (18장) ✓
```

**교훈(회사에서 생성기 만들 때):** PS 5.1 + 비ASCII = 깨짐. 생성 스크립트는 ASCII로,
글리프는 엔티티로. 배포물은 `node --check`로 인라인 JS 먼저 검사.

### 6b. 이미지 비율 왜곡 버그 (이미지 카드)

**증상:** PNG 다운로드 시 이미지가 들어간 카드의 비율이 변형(가로로 늘어남).

**원인:** **html2canvas 1.4.1은 `object-fit:cover`도 `background-size:cover`도 무시**하고
이미지를 박스에 강제로 늘림(stretch-to-fill). 합성 원(circle) 테스트로 확인:
- object-fit: ratio 1.83 (가로 늘어남), background-size: ratio 2.45 (더 심함)

**해결:** 이미지를 **박스 비율로 미리 center-cover 크롭**해서 넣음. 박스를 고정
픽셀(이미지 1080×960 + 캡션바 120 = 1080)로 만들고, 소스를 1080×960으로 크롭 후 `<img>`로
삽입 → html2canvas가 늘려도 이미 박스와 동일 비율이라 **1:1 무왜곡**.
- 생성기: `To-Base64JpegCover` (System.Drawing center-cover crop)
- CSS: `.card.image .media { height:960px }`, `.cap-bar { height:120px }`, 카드 border 0
- 검증(헤드리스): pre-crop 후 원 ratio **0.974 ≈ 1.0 (PASS)**, 단발/ZIP 다운로드도 정상

---

## 7. 다운로드 사용법 (최종)

- 카드 위 마우스오버 → **`↓ PNG`** = 그 카드 1장 저장
- 좌상단 **`↓ Download all (ZIP)`** = 전체를 `1pd-...-portraits.zip` 하나로 저장
- 라이브러리 미로드 시 경고창이 뜸 (html2canvas.min.js / jszip.min.js 동봉 확인)

---

## 8. 배포 패키지

`card-news-skill-package.zip` (프로젝트 폴더):
`card-news/`(스킬+로컬 라이브러리 2종) + `inbox/`(템플릿) + WORKLOG + 설치방법.txt
→ 회사 장비: 압축 풀어 `card-news/`를 `~/.claude/skills/`에, `inbox/`는 콘텐츠 폴더에.

---

## 9. 다음에 할 일 (TODO)

- [ ] 회사 장비 설치·동작 확인 (3대)
- [ ] 사내망 CDN/폰트 차단 시: Inter/Plex 폰트도 로컬 번들 (현재 폰트만 Google Fonts)
- [ ] 개인 브랜딩 로고 → `.foot` 슬롯에 삽입 (현재 텍스트만)
- [ ] 생성기 일반화: 포스트별 텍스트를 post.md에서 읽어 자동 주입 (현재 `_build-deck.ps1`은 이번 포스트 하드코딩)
- [ ] 비율 옵션(4:5 등) — 포트레이트 더 크게 보여주고 싶을 때
- [ ] Threads 포스트 URL → 카드뉴스 입력 경로(보조)

## 10. 참고 — 프로젝트 폴더의 도구/자산

- `_build-deck.ps1` — 덱 재생성기 (ASCII 전용 + cover-crop). 이번 포스트 내용 하드코딩
- `_test-download.js` — 다운로드 헤드리스 검증 (단발 PNG + ZIP)
- `_aspect-test.js` — 이미지 비율 보존 검증 (합성 원으로 측정)
- `_diagnostic.html` — 다운로드 단계별 진단 페이지
- 헤드리스 도구는 `npm i puppeteer-core` 후 사용 (설치된 Chrome 자동 인식)
- 원본 디자인 시스템: `StudioBlank Design System\` (스킬 런타임엔 불필요, 참고용)
- 폰트: Inter + IBM Plex Mono (현재 Google Fonts CDN — 사내망 차단 시 로컬화 TODO)

---

> 끝. 회사 장비에서 `card-news-skill-package.zip` 풀고 이어가면 됩니다. 다음 작업은
> 9번 TODO부터 (실제 포스트 텍스트로 생성기 일반화 / 폰트 로컬화 / 개인 로고).
